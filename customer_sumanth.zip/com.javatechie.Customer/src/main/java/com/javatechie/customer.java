package com.javatechie;



public class customer {

	
	private int cid;

	private String cname;
	
	private int qtty;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public customer() {
		super();
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getQtty() {
		return qtty;
	}
	public void setQtty(int qtty) {
		this.qtty = qtty;
	}
	
		// TODO Auto-generated constructor stub
	
	public customer(int cid, String cname, int qtty) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.qtty = qtty;
	}
	
}

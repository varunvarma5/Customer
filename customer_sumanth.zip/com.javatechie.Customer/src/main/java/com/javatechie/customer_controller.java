package com.javatechie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Customer")
public class customer_controller {

	@Autowired
	private Customer_Service customer_service;
	
	@PostMapping(path="/bookCustomer",produces=MediaType.APPLICATION_JSON_VALUE)
	public void bookCustomer(@RequestBody customer cust){
		 customer_service.bookCustomer(cust);
		
	}
	
}

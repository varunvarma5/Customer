package com.javatechie;

import org.springframework.stereotype.Service;

@Service
public class Customer_Service {

	
	private Customer_repository customer_repository;
	
	public Customer_Service(Customer_repository customer_repository) {
		super();
		this.customer_repository = customer_repository;
	}

	public void bookCustomer(customer cust){
		customer_entity ce=new customer_entity();
		ce.setCid(cust.getCid());
		ce.setCname(cust.getCname());
		ce.setQtty(cust.getQtty());
		//customer_repository.save(ce);
		
	}
	
}

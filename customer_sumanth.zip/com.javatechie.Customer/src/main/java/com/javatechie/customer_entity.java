package com.javatechie;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CustomerTable")
public class customer_entity {
	@Id
	@Column(name="id")
	private int cid;
	@Column(name="name")
	private String cname;
	public customer_entity() {
		super();
	}
	@Column(name="qty")
	private int qtty;
	
	public customer_entity(int cid, String cname, int qtty) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.qtty = qtty;
	}
	@Column(name="id")
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	@Column(name="name")
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Column(name="qty")
	public int getQtty() {
		return qtty;
	}
	public void setQtty(int qtty) {
		this.qtty = qtty;
	}
}
